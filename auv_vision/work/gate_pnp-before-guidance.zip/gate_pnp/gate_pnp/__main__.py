"""Configuration check only: never loads weights, images or sample keypoints."""
import argparse
import json
from pathlib import Path
from . import PnPConfig, PoseResult, Status, geometry_from_files, estimate_gate_pose


def main():
    root=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description='Check gate PnP configuration without model or keypoints')
    parser.add_argument('--calibration',type=Path,default=root/'config/front_camera.yaml')
    parser.add_argument('--vision',type=Path,default=root/'config/vision.yaml')
    parser.add_argument('--pnp-config',type=Path,default=root/'config/pnp.json')
    parser.add_argument('--export-geometry',type=Path,help='Explicitly save derived camera geometry JSON')
    args=parser.parse_args()
    try:
        config=PnPConfig.from_file(args.pnp_config)
        geometry=geometry_from_files(args.calibration,args.vision)
        if args.export_geometry:
            geometry.save(args.export_geometry)
        result=estimate_gate_pose(None,geometry,config)
    except Exception as exc:
        result=PoseResult(Status.CONFIG_ERROR,str(exc))
    print(json.dumps(result.to_dict(),ensure_ascii=True,indent=2,allow_nan=False))
    return 2 if result.status==Status.CONFIG_ERROR else 0


if __name__=='__main__':
    raise SystemExit(main())
